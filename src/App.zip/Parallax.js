const Parallax = (props)=>{
    return(
        <>
        <div className="box-3">
            <div className="image">
                <img src={props.image2 } alt="" />
            </div>
            <div className="name2">
                {props.name2}
            </div>
        </div>
            {/* </div> */}
        </>
    )
}
export default Parallax;